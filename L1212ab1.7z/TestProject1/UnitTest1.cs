using ConsoleApp1;

namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {

            Backpack b = new Backpack(4, 50, 50);
            Assert.Pass();
        }
    }
}