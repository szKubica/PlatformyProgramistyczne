﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

[assembly: InternalsVisibleTo("TestProject1")]
namespace ConsoleApp1
{

     internal class Backpack
    {


        public List<(int, int)> items;
        public int capacity;
        public List<(int, int)> generateItems(int seed, int n)
        {
            var items = new List<(int, int)>();
            Random rnd = new Random(seed);
            

            for(int i=0; i<n; i++)
            {
               int weight= rnd.Next(1, 100);
               int value = rnd.Next(1, 100);
               items.Add((weight, value));
            }



            return items;
        }

       public void sortItems()
        {
            for(int i=0; i<this.items.Count; i++)
            {
                for(int j=0; j< items.Count -1; j++)
                {
                    if (items[j].Item2 / items[j].Item1 < items[j + 1].Item2 / items[j+1].Item1)
                    {
                        (int, int) temp = items[j];
                        items[j] = items[j + 1];
                        items[j + 1] = temp;
                    }
                }
            }

            Console.WriteLine(this.items[0].Item2);
            Console.WriteLine(this.items[1].Item2);
            Console.WriteLine(this.items[2].Item2);
            Console.WriteLine(this.items[3].Item2);
        }


       public List<(int, int)> chooseItems()
        {
            var stolenItems = new List<(int, int)>();
            int currentCapacity = 0;

          
                for(int i=0; i<items.Count; i++)
                {
                    if (items[i].Item1 <= this.capacity - currentCapacity)
                    {
                        stolenItems.Add(items[i]);
                    currentCapacity+= items[i].Item1;
                    }
                }

           
            for(int i=0; i<stolenItems.Count; i++)
            {
                Console.WriteLine(stolenItems[i]);
            }

            return stolenItems;
        }
        


        public Backpack(int seed, int n, int capacity)
        {
            this.items = generateItems(seed, n);
            this.capacity = capacity;
        }



        
    }
}
