﻿namespace ConsoleApp1




{
    internal class Program
    {

    
        static void Main(string[] args)
        {
     
            Backpack b = new Backpack(4, 50, 50);
            b.sortItems();
            b.chooseItems();
        }
    }
}